#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

// Builds the kernel dump report as plain text. Requires the ClearSword
// primitives to be live (gPrimitives.kreadbuf) and gSystemInfo to be
// populated (XPF dynamic offsets + hardcoded ladders). Every symbol lookup is
// guarded: missing keys and untranslatable addresses are logged and skipped,
// never dereferenced blindly.
@interface KPDump : NSObject

// Boot constants + EXP-02 harvest: fills
// kernelConstant.base/virtBase/physBase/physSize/cpuTTEP (PAC-stripped, with
// cpu_ttep kept as TTBR phys per field data) and, when derivable,
// sptmBase/sptmSlide/txmBase/txmSlide. Only the EL2 SPTM/TXM image domain
// (0xfffffff01…/0xfffffff02…) is never read — it panics on touch.
+ (void)initializeBootConstantsGuarded;

// Full dump. Returns the report text (also streamed to KPLog as it builds).
+ (NSString *)buildReport;

// Experiment (A0): safe write proof — same-value rewrite on mach_kobj_count.
// Never panics; PASS proves kwrite works end-to-end.
+ (NSString *)sptmWriteTestReport;

// Experiment (A1): frame_table write — MAY PANIC. Only meaningful after A0
// passes. Scans for a zero entry, writes a marker, reads back, restores.
+ (NSString *)sptmFrameTableWriteTestReport;

// EXP-01: resolve the real allproc list head. Tries, in order: an alternate
// static pair for this kernelcache, the XPF anchor pair, an anchor-drift
// scan, then a zone-name route from our corrupted inpcb (content-calibrated).
// Returns the head whose chain contains pid 0 / "kernel_task", or 0.
+ (uint64_t)resolveAllprocHeadWithLog:(nullable NSMutableString *)log;

// Walk the resolved chain to a pid (pid offset is calibrated, see below).
+ (uint64_t)findProcByPid:(uint32_t)pid log:(nullable NSMutableString *)log;

// Walk the resolved chain matching our own comm — independent of p_pid.
+ (uint64_t)findSelfProcByComm:(nullable NSMutableString *)log;

// Calibrate p_pid against kernel_task=0 / launchd=1 / self=getpid().
+ (void)calibratePidOffset:(nullable NSMutableString *)log;

// Zone-name fallback: inpcb → zone("inpcb") → zone("proc") → our proc,
// validated by the proc_ro→ucred→cr_uid == getuid() hop.
+ (uint64_t)zoneRouteSelfProcWithLog:(nullable NSMutableString *)log;

// EXP-02: scan the 16 tagged pointers at SPTMArgs for the DEBG debug header
// and recover SPTM/TXM runtime bases+slides; falls back to a pointer-vote
// derivation over the libsptm shared pages. Idempotent.
+ (BOOL)harvestSptmTxmBasesWithLog:(nullable NSMutableString *)log;

// Stripped pointee VAs of the libsptm kernel block (cached).
+ (NSArray<NSNumber *> *)libsptmBlockPointeesWithLog:(nullable NSMutableString *)log;

// Slide derivation by pointer voting against known SPTM/TXM static offsets.
+ (BOOL)deriveSptmTxmSlidesByVote:(nullable NSMutableString *)log;

// EXP-01..03 survey report: fixed allproc walk, debug-header harvest,
// frame-table + 63 frame-type descriptors + PAPT ranges, calibrated
// frame-type enum and the writability predicate. Read-only.
+ (NSString *)sptmSurveyReport;

// EXP-09: forge a ucred (uid/gid 0, NULL MAC label, bumped refcount) in a
// pipe buffer (XNU_DEFAULT heap we control), then swap our proc's
// proc_ro->p_ucred pointer at it. Frame-type pre-filter gates the write.
// The forged object is never freed and the original pointer is only logged.
+ (NSString *)ucredHeapSwapReport;

@end

NS_ASSUME_NONNULL_END
