#import <UIKit/UIKit.h>
#import "KPAppDelegate.h"

int main(int argc, char *argv[]) {
    @autoreleasepool {
        NSLog(@"[KexProof] launch");
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([KPAppDelegate class]));
    }
}
